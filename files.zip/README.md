# 🚀 LaraMulti — Laravel Multi-Tenant SaaS Starter Kit

> A production-ready, multi-tenant SaaS boilerplate built on Laravel 13, Vue 3, Inertia.js, and `stancl/tenancy` with full database isolation per tenant.

---

## ✨ Overview

**LaraMulti** is a developer-first SaaS starter kit designed for founders and agencies who want to launch multi-tenant applications fast without rebuilding the same boilerplate every time.

Each tenant gets their **own isolated database**, ensuring complete data separation, performance isolation, and easy per-tenant backup and migration.

---

## 🧩 Key Features

### Central (Super Admin)
- 🏢 Tenant registration, management, suspend/activate
- 📦 Plan management (Free / Pro / Enterprise)
- 💳 Subscription management with Stripe Cashier hooks
- 🔐 Global impersonation — login as any tenant user
- 🌐 Domain & subdomain routing per tenant
- 📊 FilamentPHP admin panel

### Tenant (Per SaaS Instance)
- 👤 Full authentication (Login, Register, Password Reset, 2FA)
- 🛡️ Role & Permission system (Spatie Laravel Permission)
- 👥 Team member invitations (email-based)
- ⚙️ Tenant settings (branding, timezone, locale, logo)
- 💳 Billing portal stub (Stripe Cashier ready)
- 🔑 API token management (Laravel Sanctum)

### Developer Experience
- 🗄️ Auto database creation on tenant provisioning
- 🧪 Tenant & central seeders
- 🎯 Artisan commands for tenant management
- 📬 Queue isolation per tenant
- 🗂️ Storage isolation per tenant (S3-compatible)
- 🔁 Tenant-aware job dispatching
- 📝 Full .env documentation

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Framework | Laravel 13 |
| Multi-tenancy | `stancl/tenancy` v3 |
| Frontend | Vue 3 + Inertia.js |
| Styling | Tailwind CSS v4 |
| Admin Panel | FilamentPHP v5 |
| Auth | Laravel Breeze (Inertia preset) |
| Permissions | Spatie Laravel Permission |
| Payments | Laravel Cashier (Stripe) |
| Queue | Laravel Horizon + Redis |
| API Auth | Laravel Sanctum |
| Database | MySQL 8+ |
| Cache | Redis |

---

## 📁 Repository Structure

```
laramulti/
├── app/
│   ├── Central/               # Central app logic
│   │   ├── Models/
│   │   ├── Http/Controllers/
│   │   ├── Http/Middleware/
│   │   └── Services/
│   ├── Tenant/                # Tenant-scoped logic
│   │   ├── Models/
│   │   ├── Http/Controllers/
│   │   ├── Http/Middleware/
│   │   └── Services/
│   └── Shared/                # Shared traits and base classes
├── database/
│   ├── migrations/
│   │   ├── central/           # Central DB migrations
│   │   └── tenant/            # Tenant DB migrations
│   └── seeders/
│       ├── CentralSeeder.php
│       └── TenantSeeder.php
├── resources/
│   └── js/
│       ├── Central/           # Super admin Vue pages
│       ├── Tenant/            # Tenant Vue pages
│       └── Shared/            # Shared components
├── routes/
│   ├── web.php                # Central routes
│   ├── tenant.php             # Tenant routes
│   └── api.php
├── config/
│   └── tenancy.php            # Tenancy configuration
└── docs/                      # This documentation
```

---

## 📋 Requirements

| Requirement | Version |
|---|---|
| PHP | 8.3+ |
| Laravel | 12.x |
| MySQL | 8.0+ |
| Redis | 6.0+ |
| Node.js | 20+ |
| Composer | 2.x |

---

## ⚡ Quick Start

```bash
# 1. Clone the repository
git clone https://github.com/your-org/laramulti.git
cd laramulti

# 2. Install PHP dependencies
composer install

# 3. Install Node dependencies
npm install

# 4. Copy environment file
cp .env.example .env

# 5. Generate app key
php artisan key:generate

# 6. Configure your .env (see INSTALLATION.md)

# 7. Run central migrations
php artisan migrate --database=central

# 8. Seed super admin
php artisan db:seed --class=CentralSeeder

# 9. Build frontend assets
npm run build

# 10. Start the development server
php artisan serve
```

---

## 📚 Documentation Index

| File | Description |
|---|---|
| [INSTALLATION.md](./INSTALLATION.md) | Full installation & environment setup |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Database schema, tenancy flow, folder structure |
| [FEATURES.md](./FEATURES.md) | Detailed feature breakdown with code examples |
| [DEVELOPMENT.md](./DEVELOPMENT.md) | Extending the kit, Artisan commands, customization |
| [DEPLOYMENT.md](./DEPLOYMENT.md) | Production deployment, Nginx, queues, SSL |
| [CHANGELOG.md](./CHANGELOG.md) | Version history |

---

## 🧑‍💻 Author

Built by a full-stack developer with 8+ years in Laravel SaaS & ride-hailing platforms.  
Available for custom development on [Fiverr](#).

---

## 📄 License

This script is sold under the **CodeCanyon Regular/Extended License**.  
See `LICENSE.txt` for full terms.
